#ifndef PUBLIC_H
#define PUBLIC_H
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#define COM_FILE "/dev/ttyUSB0"
#define CONFIG_TABNAME "config"
#define ERRLOG(errmsg)                                                            \
    do {                                                                          \
        perror(errmsg);                                                           \
        printf("file : %s, func: %s, line : %d\n", __FILE__, __func__, __LINE__); \
        exit(-1);                                                                 \
    } while (0);

typedef struct send_job {
    int type; // 0:串口    1:TCP单发    2:TCP群发
    int fd;
    void *data; // 待发送数据
    struct send_job *next;
} send_job;

typedef struct Queue {
    send_job *head;
    send_job *tail;
} Queue;

typedef struct Data_to_Client {
    /*111--注册成功       100--注册失败
     *222--登录成功       200--未注册      201-- 密码错误
     *333--控制成功(开关操作)      300--控制失败
     *444--配置成功        400--配置失败
     *555--返回环境信息
     *999--出错       */
    int cmd;           // 命令码
    int temp;          // 温度
    int hum;           // 湿度
    int ill;           // 光照强度
    int temp_max;      // 温度上限
    int temp_min;      // 温度下限
    int hum_max;       // 湿度上限
    int hum_min;       // 湿度下限
    int auto_temp_max; // 自动温度上限
    int auto_temp_min; // 自动温度上限
    int auto_ill_max;  // 自动光照强度上限
    int auto_ill_min;  // 自动光照强度上限
} Data_to_Client;


/*上行数据结构体*/
typedef struct Env_info {
    uint8_t head[3]; // 标识位st
    uint8_t type;    // 数据类型
    uint8_t snum;    // 房间编号
    uint8_t temp[2]; // 温度
    uint8_t hum[2];  // 湿度
    uint8_t X;       // 三轴信息
    uint8_t y;
    uint8_t Z;
    uint32_t ill; // 光照
    uint32_t bet; // 电池电量
    uint32_t adc; // 电位器信息
} Env_info;


typedef struct queryTab_config {
    int temp_max;
    int temp_min;
    int hum_max;
    int hum_min;
    int auto_temp_max;
    int auto_temp_min;
    int auto_ill_max;
    int auto_ill_min;
}queryTab_config;

Queue *queue_Init();
void queuePush(Queue *p, int type, int fd, void *data);
void queueOut(Queue *p);
#endif