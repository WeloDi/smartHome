#ifndef SERIAL_H
#define SERIAL_H
#include "public.h"
#include <termios.h>

int serial_init(int fd);
float dota_atof(char unitl);
void sendToserial();
void autoCtrl(sqlite3 *db, const Env_info *envinfo, int serialfd, Queue *queue);
#endif