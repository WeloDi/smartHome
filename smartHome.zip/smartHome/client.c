#include "client.h"

void dealWithClient(int clientfd)
{
    extern sqlite3 *db;
    while (1) {
        Data_from_Client data_recv;
        int ret;
        ret = recv(clientfd, &data_recv, sizeof(data_recv), 0);
        if (ret == -1) {
            ERRLOG("recv");
        }
        if (ret == 0) {
            disConnected(clientfd);
        } else {
            convertToHostByteOrder(&data_recv);
            printf("ID:%d\nPSWORD:%d\nCMD:%d\n", data_recv.ID, data_recv.psword, data_recv.cmd);
            switch (data_recv.cmd) {
            case 100: // 注册
                Signup(db, data_recv, clientfd);
                break;
            case 200: // 登录
                Login(db, data_recv, clientfd);
                break;
            case 300: // 硬件控制
                devControl(clientfd, &data_recv);
                break;
            case 400: // 修改配置
                devConfig(db, &data_recv, clientfd);
                break;
            default:
                break;
            }
        }
    }
    return;
}

void disConnected(int clientfd)
{
    extern int epollfd;
    extern struct epoll_event ev;
    extern Client_info clientinfo;
    printf("连接关闭:%d\n", clientfd);
    close(clientfd);
    ev.events = EPOLLIN;
    ev.data.fd = clientfd;
    epoll_ctl(epollfd, EPOLL_CTL_DEL, clientfd, &ev);
    clientinfo.curlen--;
    return;
}

void Signup(sqlite3 *db, Data_from_Client dataFromClient, int clientfd)
{
    extern Queue *queue;
    Data_to_Client *dataToClient = (Data_to_Client *)malloc(sizeof(Data_to_Client));
    SqlQueryRet ret;
    memset(dataToClient, 0, sizeof(Data_to_Client));
    memset(&ret, 0, sizeof(ret));

    char ID[11] = {0};
    sprintf(ID, "%d", dataFromClient.ID);

    // 查询数据库中是否已有此账户
    ret = sqliteQuery(db, USER_TABNAME, ID);
    if (ret.exist) {
        dataToClient->cmd = 100;
    } else {
        if (sqliteInsert(db, &dataFromClient)) {
            dataToClient->cmd = 111;
        } else {
            dataToClient->cmd = 100;
        }
    }
    queuePush(queue, 1, clientfd, dataToClient);
}

void Login(sqlite3 *db, Data_from_Client dataFromClient, int clientfd)
{
    extern Queue *queue;
    Data_to_Client *dataToClient = (Data_to_Client *)malloc(sizeof(Data_to_Client));
    SqlQueryRet ret;
    memset(dataToClient, 0, sizeof(Data_to_Client));
    memset(&ret, 0, sizeof(ret));

    char ID[11] = {0};
    sprintf(ID, "%d", dataFromClient.ID);

    ret = sqliteQuery(db, USER_TABNAME, ID);
    if (!ret.exist) {
        dataToClient->cmd = 200; // 未注册
    } else {

        char psword[11] = {0};
        sprintf(psword, "%d", dataFromClient.psword);

        if (strcmp(psword, ret.psword) == 0) {
            dataToClient->cmd = 222;                             // 登录成功
            sqliteUpdata(db, USER_TABNAME, &dataFromClient, ID); // 登录状态更新
        } else {
            dataToClient->cmd = 201; // 密码错误
        }
    }

    // 登录时将当前配置一并发送
    queryTab_config config_ret = queryConfigTab(db);

    dataToClient->temp_max = config_ret.temp_max;
    dataToClient->temp_min = config_ret.temp_min;
    dataToClient->hum_max = config_ret.hum_max;
    dataToClient->hum_min = config_ret.hum_min;
    dataToClient->auto_temp_max = config_ret.auto_temp_max;
    dataToClient->auto_temp_min = config_ret.auto_temp_min;
    dataToClient->auto_ill_max = config_ret.auto_ill_max;
    dataToClient->auto_ill_min = config_ret.auto_ill_min;

    printf("***************************%d************************\n", dataToClient->cmd);
    queuePush(queue, 1, clientfd, dataToClient);
    return;
}

void devControl(int clientfd, Data_from_Client *data)
{
    extern Queue *queue;
    extern int serialfd;
    // 发送给客户端
    Data_to_Client *dataToClient = (Data_to_Client *)malloc(sizeof(Data_to_Client));
    memset(dataToClient, 0, sizeof(Data_to_Client));
    // 发送给端口
    unsigned char *dataToSerial = (unsigned char *)malloc(sizeof(unsigned char));
    memset(dataToSerial, 0, sizeof(unsigned char));

    // 设置房间号（bit:7-6）
    *dataToSerial |= (1 << 7);

    switch (data->ctrl_switch) {
    case 100: // 关灯
        *dataToSerial |= 1 << 5;
        break;
    case 101: // 开灯
        *dataToSerial |= 1 << 5;
        *dataToSerial |= 0x1;
        break;
    case 200: // 关风扇

        break;
    case 201: // 风扇1档
        *dataToSerial |= 0x1;
        break;
    case 202: // 风扇2档
        *dataToSerial |= 0x2;
        break;
    case 203: // 风扇3档
        *dataToSerial |= 0x3;
        break;
    case 300: // 蜂鸣器关
        *dataToSerial |= 1 << 4;
        break;
    case 301: // 蜂鸣器开
        *dataToSerial |= 1 << 4;
        *dataToSerial |= 0x1;
        break;
    default:
        break;
    }

    dataToClient->cmd = 333;

    queuePush(queue, 0, serialfd, dataToSerial);
    queuePush(queue, 1, clientfd, dataToClient);
    return;
}

void devConfig(sqlite3 *db, Data_from_Client *data, int clientfd)
{
    extern Queue *queue;
    Data_to_Client *dataToClient = (Data_to_Client *)malloc(sizeof(Data_to_Client));
    memset(dataToClient, 0, sizeof(Data_to_Client));

    sqliteUpdata(db, CONFIG_TABNAME, data, NULL);

    dataToClient->cmd = 444;

    queuePush(queue, 1, clientfd, dataToClient);
    return;
}

sqlite3 *openDatabase()
{
    // 打开/创建数据库
    extern sqlite3 *db;
    if (sqlite3_open(DBNAME, &db) != SQLITE_OK) {
        printf("数据库database.db打开/创建失败:%s\n", sqlite3_errmsg(db));
        exit(-1);
    } else {
        printf("数据库database.db打开/创建成功\n");
    }

    // 创建/打开表
    char sql_1[SQL_N] = {0};
    char sql_2[SQL_N] = {0};
    char *sql[2] = {sql_1, sql_2};
    char *errmsg;
    int errcode = 0;
    char *tabname[2] = {USER_TABNAME, CONFIG_TABNAME};
    sprintf(sql_1, "create table %s (ID char primary key, psword char,status int);", USER_TABNAME);
    sprintf(sql_2, "create table %s (mod int, temp_max int, temp_min int, hum_max int, hum_min int, auto_temp_max int, auto_temp_min int, auto_ill_max int ,  auto_ill_min  int);", CONFIG_TABNAME);

    for (int i = 0; i < 2; i++) {
        if ((errcode = sqlite3_exec(db, sql[i], NULL, NULL, &errmsg)) != SQLITE_OK) {
            if (errcode == 1) {
                printf("打开表%s成功\n", tabname[i]);
            } else {
                printf("创表%s失败: %s\n", tabname[i], errmsg);
                exit(-1);
            }
        } else {
            printf("创表%s成功\n", tabname[i]);

            // 设置默认配置
            if (1 == i) {
                char temp[SQL_N] = {0};
                sprintf(temp, "insert into %s values('%d','%d', '%d','%d', '%d','%d', '%d','%d', '%d')", CONFIG_TABNAME, 1, 25, 0, 15, 0, 30, 30, 250, 150);
                if (sqlite3_exec(db, temp, NULL, NULL, &errmsg) != SQLITE_OK) {
                    printf("初始化配置出错 : %s\n", errmsg);
                    exit(-1);
                }
            }
        }
    }
    return db;
}

/*查询用户表中是否有目标字段,并返回行信息*/
SqlQueryRet sqliteQuery(sqlite3 *db, char *tabname, char *ID)
{
    char sql[SQL_N] = {0};
    char *errmsg;
    char **result;
    int nclomn, nrow;

    SqlQueryRet ret;
    memset(&ret, 0, sizeof(ret));

    sprintf(sql, "select * from %s where ID = %s", tabname, ID);
    if (sqlite3_get_table(db, sql, &result, &nrow, &nclomn, &errmsg) != SQLITE_OK) {
        ret.exist = 0;
        return ret;
    }
    if (nrow != 0) {
        ret.exist = 1;
        strcpy(ret.psword, result[1]);
        ret.status = atoi(result[2]);
        return ret;
    }

    ret.exist = 0;
    return ret;
}

/*向用户表中插入一条新的用户信息*/
bool sqliteInsert(sqlite3 *db, Data_from_Client *dataFromClient)
{
    char sql[SQL_N] = {0};
    char *errmsg;

    char ID[11], psword[11];
    sprintf(ID, "%d", dataFromClient->ID);
    sprintf(psword, "%d", dataFromClient->psword);

    sprintf(sql, "insert into %s values('%s', '%s',%d)", USER_TABNAME, ID, psword, 1);

    if (sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK) {
        printf("插入用户信息出错 : %s\n", errmsg);
        return false;
    }
    return true;
}

/*更新表中字段,更改配置表时ID可填空*/
bool sqliteUpdata(sqlite3 *db, char *tabname, Data_from_Client *data, char *ID)
{
    char sql[SQL_N] = {0};
    char *errmsg;

    if (0 == strcmp(tabname, USER_TABNAME)) {
        sprintf(sql, "update %s set status = %d where ID = %s", tabname, 1, ID);
    } else {
        sprintf(sql, "update %s set mod=%d, temp_max = %d, temp_min = %d, hum_max = %d, hum_min = %d, auto_temp_max = %d, auto_temp_min = %d, auto_ill_max = %d, auto_ill_min = %d",
                tabname, data->mod, data->temp_max, data->temp_min, data->hum_max, data->hum_min, data->auto_temp_max, data->auto_temp_min, data->auto_ill_max, data->auto_ill_min);
    }

    if (sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK) {
        return false;
    } else {
        printf("Update done\n");
    }
    return true;
}

queryTab_config queryConfigTab(sqlite3 *db)
{
    char **result;
    int rows, columns;
    char *errmsg;
    queryTab_config ret;

    char sql[SQL_N];
    snprintf(sql, sizeof(sql), "SELECT * FROM %s LIMIT 1;", CONFIG_TABNAME);

    if (sqlite3_get_table(db, sql, &result, &rows, &columns, &errmsg) != SQLITE_OK) {
        printf("config查询失败: %s\n", errmsg);
    } else {
        if (rows == 0) {
            printf("config表中无数据\n");
        } else {
            ret.temp_max = atoi(result[++columns]);
            ret.temp_min = atoi(result[++columns]);
            ret.hum_max = atoi(result[++columns]);
            ret.hum_min = atoi(result[++columns]);
            ret.auto_temp_max = atoi(result[++columns]);
            ret.auto_temp_min = atoi(result[++columns]);
            ret.auto_ill_max = atoi(result[++columns]);
            ret.auto_ill_min = atoi(result[++columns]);
        }
    }
    return ret;
}

/*查看当前配置是否为自动*/
bool isAuto(sqlite3 *db)
{
    char sql[150] = {0};
    char *errmsg;
    char **result;
    int nclomn, nrow;
    sprintf(sql, "select * from %s", CONFIG_TABNAME);
    if (sqlite3_get_table(db, sql, &result, &nrow, &nclomn, &errmsg) != SQLITE_OK) {
        ERRLOG("select * from config");
    }

    if (nrow == 1) {
        if (result[1][0] == 1) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

float ntohf(float networkFloat)
{
    unsigned int networkInt;
    unsigned int hostInt;
    memcpy(&networkInt, &networkFloat, sizeof(unsigned int));
    networkInt = ntohl(networkInt);
    memcpy(&hostInt, &networkInt, sizeof(unsigned int));
    return *(float *)&hostInt;
}

void convertToHostByteOrder(Data_from_Client *data)
{
    data->cmd = ntohl(data->cmd);
    data->mod = ntohl(data->mod);
    data->ctrl_switch = ntohl(data->ctrl_switch);
    data->ID = ntohl(data->ID);
    data->psword = ntohl(data->psword);
    // data->temp_min = ntohf(data->temp_min);
    // data->hum_max = ntohf(data->hum_max);
    // data->hum_min = ntohf(data->hum_min);
    // data->auto_temp_max = ntohf(data->auto_temp_max);
    // data->auto_temp_min = ntohf(data->auto_temp_min);
    // data->auto_ill_max = ntohf(data->auto_ill_max);
    // data->auto_ill_min = ntohf(data->auto_ill_min);
    data->temp_max = ntohl(data->temp_max);
    data->temp_min = ntohl(data->temp_min);
    data->hum_max = ntohl(data->hum_max);
    data->hum_min = ntohl(data->hum_min);
    data->auto_temp_max = ntohl(data->auto_temp_max);
    data->auto_temp_min = ntohl(data->auto_temp_min);
    data->auto_ill_max = ntohl(data->auto_ill_max);
    data->auto_ill_min = ntohl(data->auto_ill_min);
}

void convertToNetworkByteOrder(Data_to_Client *data)
{
    data->cmd = htonl(data->cmd);
    data->temp = htonl(data->temp);
    data->hum = htonl(data->hum);
}

/*flag: 单发传0,多发传1*/
void sendToClient(bool flag)
{
    extern Client_info clientinfo;
    extern Queue *queue;
    // 取出队首要发送的数据
    Data_to_Client *data = (Data_to_Client *)queue->head->data;
    // 转换网络字节序
    convertToNetworkByteOrder(data);
    // 将转换后的数据再放入队首
    queue->head->data = data;

    if (flag) {
        for (int i = 0; i < clientinfo.curlen; i++) {
            send(clientinfo.clientfd[i], (Data_from_Client *)queue->head->data, sizeof(Data_from_Client), 0); // 群发
        }
    } else {
        send(queue->head->fd, (Data_from_Client *)queue->head->data, sizeof(Data_from_Client), 0); // 单发
    }
    queueOut(queue);
}
