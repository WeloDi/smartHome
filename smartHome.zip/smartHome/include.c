#include "include.h"

/*创建服务器并开始监听，返回socket文件描述符*/
int init_socket(const char *IP, const char *Port)
{
    // 创建socket
    int sockfd = -1;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
        ERRLOG("socket");

    // 创建服务器的网络信息结构体
    struct sockaddr_in serveraddr;
    int addrlen = sizeof(serveraddr);
    memset(&serveraddr, 0, sizeof(struct sockaddr_in));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(atoi(Port));
    serveraddr.sin_addr.s_addr = inet_addr(IP);

    // 设置端口复用
    int option = 1;
    if (-1 == setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option))) {
        ERRLOG("setsockopt");
    }

    // 设置接收超时时间
    // struct timeval tm;
    // tm.tv_sec = 5;
    // tm.tv_usec = 0;
    // if (-1 == setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tm, sizeof(tm)))
    //     ERRLOG("setsockopt");

    // 绑定socket和网络信息结构体
    if (bind(sockfd, (struct sockaddr *)&serveraddr, addrlen) == -1)
        ERRLOG("bind");

    // 开启监听
    if (listen(sockfd, 5) == -1) {
        ERRLOG("listen");
    }
    printf("--------------------------<服务器已开启>-------------------------\n");
    return sockfd;
}

/*初始化epoll,传入socket文件描述符*/
void setEpoll(int sockfd, int *epollfd, struct epoll_event *ev)
{
    // 创建epoll实例
    if ((*epollfd = epoll_create(1)) == -1)
        ERRLOG("epoll_create");

    // 将监听的socket对应的文件描述符添加到epoll事件列表中
    ev->data.fd = sockfd;
    ev->events = EPOLLIN;
    if (-1 == epoll_ctl(*epollfd, EPOLL_CTL_ADD, sockfd, ev)) {
        ERRLOG("epoll_ctl");
    }
}

void *recvFromClient(void *arg)
{
    pthread_detach(pthread_self());
    Thread0_arg para = *(Thread0_arg *)arg;

    while (1) {
        int nreadys;
        if ((nreadys = epoll_wait(para.epollfd, para.event, 100, -1)) == -1)
            ERRLOG("epoll_wait");
        printf("nreadys:%d\n", nreadys);
        if (nreadys == 0)
            printf("timeout...\n");

        for (int i = 0; i < nreadys; i++) {
            if (para.event[i].data.fd == para.sockfd) {
                // 接收新的客户端
                newClient(para.sockfd, para.epollfd, para.ev);
            } else {
                // 处理客户端信息
                dealWithClient(para.event[i].data.fd);
            }
        }
    }
}

void *recvFromSerial(void *arg)
{
    pthread_detach(pthread_self());
    extern Queue *queue;
    extern int serialfd;
    extern Env_info envinfo;
    extern sqlite3 *db;

    int temp;
    int hum;
    int ill;

    int ret = 0;
    while (1) {
        memset(&envinfo, 0, sizeof(envinfo));
        ret = read(serialfd, &envinfo, sizeof(envinfo));
        if (ret != sizeof(envinfo)) {
            printf("errno=%d\n", errno);
            perror("read M0 data failed");
            break;
        }

        // temp = envinfo.temp[0] + dota_atof(envinfo.temp[1]);
        // hum = envinfo.hum[0] + dota_atof(envinfo.hum[1]);
        // ill = envinfo.ill;
        // printf("温度：%d   湿度：%d   光照：%d\n", temp, hum, ill);

        // 自动控制
        autoCtrl(db, &envinfo, serialfd, queue);

        Data_to_Client *dataToClient = (Data_to_Client *)malloc(sizeof(Data_to_Client));
        dataToClient->temp = envinfo.temp[0] + dota_atof(envinfo.temp[1]);
        dataToClient->hum = envinfo.hum[0] + dota_atof(envinfo.hum[1]);
        dataToClient->ill = envinfo.ill;
        dataToClient->cmd = 555;

        queuePush(queue, 2, 0, dataToClient);

        sleep(1);
    }
    return NULL;
}

void *sendData(void *arg)
{
    pthread_detach(pthread_self());
    extern Queue *queue;
    extern pthread_mutex_t mutex;
    extern pthread_cond_t cond;
    do {
        pthread_mutex_lock(&mutex);
        if (queue->head == NULL) {
            pthread_cond_wait(&cond, &mutex);
        }
        switch (queue->head->type) {
        case 0: // 串口
            sendToserial();
            break;
        case 1: // tcp单发
            sendToClient(0);
            break;
        case 2: // tcp群发
            sendToClient(1);
            break;
        default:
            break;
        }
        pthread_mutex_unlock(&mutex);
    } while (1);
}

void newClient(int sockfd, int epfd, struct epoll_event *ev)
{
    struct sockaddr_in clientaddr;
    socklen_t addrlen = sizeof(clientaddr);

    int clientfd = accept(sockfd, (struct sockaddr *)&clientaddr, &addrlen);
    if (!clientfd) {
        ERRLOG("accept");
    }
    printf("客户端:[IP] %s\t[Port] %d  连接成功\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

    // 将新的客户端链接加入到epoll中
    ev->data.fd = clientfd;
    epoll_ctl(epfd, EPOLL_CTL_ADD, clientfd, ev);

    // 将新的客户端连接加入到数组中保存
    extern Client_info clientinfo;
    clientinfo.clientfd[clientinfo.curlen++] = clientfd;
}