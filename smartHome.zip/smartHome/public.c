#include "public.h"

/*初始化队列*/
Queue *queue_Init()
{
    Queue *p = (Queue *)malloc(sizeof(Queue));
    p->head = NULL;
    p->tail = NULL;
    return p;
}

/*入列
type: 0-串口发送，1-TCP单发，2-TCP群发*/
void queuePush(Queue *p, int type, int fd, void *data)
{
    extern pthread_mutex_t mutex;
    extern pthread_cond_t cond;

    send_job *new = (send_job *)malloc(sizeof(send_job));
    new->type = type;
    new->fd = fd;
    new->next = NULL;

    if (0 == type) {
        new->data = (unsigned char *)data;
    } else {
        new->data = (Data_to_Client *)data;
    }

    pthread_mutex_lock(&mutex);

    if (p->head == NULL) {
        p->head = p->tail = new;
    } else {
        p->tail->next = new;
        p->tail = new;
    }

    pthread_mutex_unlock(&mutex);
    pthread_cond_signal(&cond);
}

/*出列*/
void queueOut(Queue *p)
{
    send_job *tmp = p->head;
    p->head = tmp->next;

    // if (tmp->type == 0) {
    //     free((unsigned char *)tmp->data);
    // } else {
    //     free((Data_to_Client *)tmp->data);
    // }

    free(tmp);
    if (p->head == NULL)
        p->tail = NULL;
}