#include "include.h"

/* 全局变量*/
int epollfd;
struct epoll_event ev, event[1024];
sqlite3 *db;
Client_info clientinfo; // 客户端信息
Queue *queue;           // 发送消息队列
Env_info envinfo;       // 当前环境信息
int serialfd;           // 串口文件描述符

// 锁&条件变量——发送数据队列
pthread_mutex_t mutex;
pthread_cond_t cond;



int main(int argc, char const *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Usage:%s <ip> <port>", argv[0]);
        return 0;
    }
    // 初始化全局变量
    db = openDatabase(); // 首次创建配置表时会写入默认配置
    queue = queue_Init();
    memset(&clientinfo, 0, sizeof(Client_info));
    memset(&envinfo, 0, sizeof(envinfo));
    pthread_cond_init(&cond, NULL);
    pthread_mutex_init(&mutex, NULL);
    serialfd = open(COM_FILE, O_RDWR);
    if (serialfd < 0) {
        ERRLOG("open failed");
    }
    serial_init(serialfd);

    // 创建socket
    int sockfd = init_socket(argv[1], argv[2]);

    // 设置epoll
    setEpoll(sockfd, &epollfd, &ev);

    pthread_t thread0;
    pthread_t thread1;
    pthread_t thread2;

    // 线程0参数
    Thread0_arg thread0_arg;
    thread0_arg.sockfd = sockfd;
    thread0_arg.epollfd = epollfd;
    thread0_arg.ev = &ev;
    thread0_arg.event = event;

    //接收客户端信息
    if (0 != pthread_create(&thread0, NULL, recvFromClient, &thread0_arg)) {
        ERRLOG("pthread_create");
    }

    // 接收串口信息
    if (0 != pthread_create(&thread1, NULL, recvFromSerial, &sockfd)) {
        ERRLOG("pthread_create");
    }

    // 发送信息
    if (0 != pthread_create(&thread2, NULL, sendData, &sockfd)) {
        ERRLOG("pthread_create");
    }

    while (1) {
    }
}
