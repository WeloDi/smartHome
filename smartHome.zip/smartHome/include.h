#ifndef INCLUDE_H
#define INCLUDE_H
#include "client.h"
#include "public.h"
#include "serial.h"

typedef struct Thread0_arg {
    int sockfd;
    int epollfd;
    struct epoll_event *ev;
    struct epoll_event *event;
} Thread0_arg;

int init_socket(const char *IP, const char *Port);
void setEpoll(int sockfd, int *epollfd, struct epoll_event *ev);

void *recvFromClient(void *arg);
void *recvFromSerial(void *arg);
void *sendData(void *arg);

void newClient(int sockfd, int epfd, struct epoll_event *ev);
#endif