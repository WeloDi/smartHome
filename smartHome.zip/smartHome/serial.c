#include "serial.h"

/*初始化端口信息*/
int serial_init(int fd)
{
    struct termios options;

    tcgetattr(fd, &options); // 获取终端参数

    options.c_cflag |= (CLOCAL | CREAD); // 忽略调制解调器线路状态   使用接收器
    options.c_cflag &= ~CSIZE;           // ～字符长度，取值范围为CS5、CS6、CS7或CS8
    options.c_cflag &= ~CRTSCTS;         // ～使用RTS/CTS流控制
    options.c_cflag |= CS8;
    options.c_cflag &= ~CSTOPB; // ～设置两个停止位，而不是一个
    options.c_iflag |= IGNPAR;
    options.c_iflag &= ~(ICRNL | IXON);
    options.c_oflag = 0;
    options.c_lflag = 0;

    cfsetispeed(&options, B115200);
    cfsetospeed(&options, B115200);

    tcsetattr(fd, TCSANOW, &options); // 设置终端参数

    sleep(1);
    tcflush(fd, TCIOFLUSH); // 将输出输出缓冲器清空
    return 0;
}

float dota_atof(char unitl)
{
    if (unitl > 100) {
        return unitl / 1000.0;
    } else if (unitl > 10) {
        return unitl / 100.0;
    } else {
        return unitl / 10.0;
    }
}

void sendToserial()
{
    extern Queue *queue;
    write(queue->head->fd, (unsigned char *)queue->head->data, 1);
    queueOut(queue);
    return;
}

void autoCtrl(sqlite3 *db, const Env_info *envinfo, int serialfd, Queue *queue)
{
    extern bool isAuto(sqlite3 * db);
    extern queryTab_config queryConfigTab(sqlite3 * db);
    unsigned char *dataToSerial = (unsigned char *)malloc(sizeof(unsigned char));

    float temperature; // 温度
    float humidity;    // 湿度
    int ill;           // 光照
    temperature = envinfo->temp[0] + dota_atof(envinfo->temp[1]);
    humidity = envinfo->hum[0] + dota_atof(envinfo->hum[1]);
    ill = envinfo->ill;

    queryTab_config ret = queryConfigTab(db);

    // if (isAuto(db)) {
    // 温度检测--开关风扇
    if (temperature >= ret.auto_temp_max) {
        *dataToSerial = 0x80;
        *dataToSerial |= 0x3;
        queuePush(queue, 0, serialfd, dataToSerial);
    } else if (temperature <= ret.auto_temp_min) {
        *dataToSerial = 0x80;
        queuePush(queue, 0, serialfd, dataToSerial);
    }
    // 光照检测--开关灯
    if (ill >= ret.auto_ill_max) {
        *dataToSerial = 0x80;
        *dataToSerial |= 1 << 5;
        queuePush(queue, 0, serialfd, dataToSerial);
    } else if (ill <= ret.auto_ill_min) {
        *dataToSerial = 0x80;
        *dataToSerial |= 1 << 5;
        *dataToSerial |= 0x1;
        queuePush(queue, 0, serialfd, dataToSerial);
    }
    // }

    // 报警
    // if (humidity >= ret.temp_max || temperature >= ret.hum_max) {
    //     // 高温/高湿报警
    //     *dataToSerial = 0x80;
    //     *dataToSerial |= 1 << 4;
    //     *dataToSerial |= 0x1;
    //     queuePush(queue, 0, serialfd, dataToSerial);
    // } else if (humidity <= ret.temp_min || temperature <= ret.hum_min) {
    //     // 低温/低湿报警
    //     *dataToSerial = 0x80;
    //     *dataToSerial |= 1 << 4;
    //     *dataToSerial |= 0x1;
    //     queuePush(queue, 0, serialfd, dataToSerial);
    // } else {
    //     // 关闭报警
    //     *dataToSerial = 0x80;
    //     *dataToSerial |= 1 << 4;
    //     queuePush(queue, 0, serialfd, dataToSerial);
    // }

    return;
}
