#ifndef CLIENT_H
#define CLIENT_H
#include "public.h"
#define CONNECT_MAXNUM 10
#define DBNAME "database.db"
#define SQL_N 200
#define USER_TABNAME "userinfo"

typedef struct Client_info {
    int clientfd[CONNECT_MAXNUM];
    int curlen;
} Client_info;

typedef struct Data_from_Client {
    int cmd;           // 命令码                   100--注册      200--登录       300--硬件控制     400--配置       500--查看环境信息    600--查看配置信息
    int mod;           // 工作模式                0--手动          1--自动
    int ctrl_switch;   // 开关控制                 100--灯关闭     101--灯打开      /   200--风扇关     201--风扇1档      202--风扇2档        203--风扇3档     /   300--蜂鸣器关闭         301--蜂鸣器打开
    int temp_max;      // 温度上限
    int temp_min;      // 温度下限
    int hum_max;       // 湿度上限
    int hum_min;       // 湿度下限
    int auto_temp_max; // 自动温度上限
    int auto_temp_min; // 自动温度上限
    int auto_ill_max;  // 自动光照强度上限
    int auto_ill_min;  // 自动光照强度上限
    int ID;            // 用户名
    int psword;        // 密码
} Data_from_Client;

typedef struct SqlQueryRet {
    bool exist; // 是否存在
    char psword[11];
    int status; // 登录状态
} SqlQueryRet;

// 处理客户端请求
void dealWithClient(int clientfd);
void disConnected(int clientfd);
void Signup(sqlite3 *db, Data_from_Client dataFromClient, int clientfd);
void Login(sqlite3 *db, Data_from_Client dataFromClient, int clientfd);
void devControl(int clientfd, Data_from_Client *data);
void devConfig(sqlite3 *db, Data_from_Client *data, int clientfd);

// 数据库相关
sqlite3 *openDatabase();
SqlQueryRet sqliteQuery(sqlite3 *db, char *tabname, char *ID);
bool sqliteInsert(sqlite3 *db, Data_from_Client *dataFromClient);
bool sqliteUpdata(sqlite3 *db, char *tabname, Data_from_Client *data, char *ID);
queryTab_config queryConfigTab(sqlite3 *db);
bool isAuto(sqlite3 *db);

// 字节转换相关
float ntohf(float networkFloat);
void convertToHostByteOrder(Data_from_Client *data);
void convertToNetworkByteOrder(Data_to_Client *data);

void sendToClient(bool flag);
#endif